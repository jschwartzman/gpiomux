//***************************************************************************
// muxmain.cpp - optional C++ main() for gpiomux.asm
// John Schwartzman, Forte Systems, Inc.
// 03/29/2021
// ARM64
//***************************************************************************

#include <iostream>		// for std::cout
#include <stdlib.h>		// for EXIT_SUCCESS
#include <signal.h>		// for signal()
#include "gpiomux.h"	// declarations for exports in gpiomux.asm

using namespace std;

//***************************************************************************
void handleHangup(int sig)
{
	cout << "muxmain: received signal "
		 << sig << " - setting flag for exit\n";
	setExitFlag();	// signal readWrite() to exit
}

//***************************************************************************
void handleSigUsr1(int sig)
{
	cout << "muxmain: received signal "
		 << sig << " - setBlinkingColon(ON)\n";
	setBlinkingColon(1);
}

//***************************************************************************
void handleSigUsr2(int sig)
{
	cout << "muxmain: received signal "
		 << sig << " - setBlinkingColon(OFF)\n";
	setBlinkingColon(0);
}

//***************************************************************************
extern int main(int argc, char** argv)
{
	// associate signals with functions
	signal(SIGHUP, handleHangup);
	signal(SIGUSR1, handleSigUsr1);
	signal(SIGUSR2, handleSigUsr2);

	cout << "muxmain: initializing\n";
	initialize();	// set up gpio and shared memory

	cout << "muxmain: running\n";
    readWrite();	// read each digit and write to appropriate 7-segment 

	cout << "muxmain: cleaning up\n";
	cleanUp();		// restore gpio to default state and unmap gpio

	cout << "muxmain: exiting\n";
	exit(EXIT_SUCCESS);
}

//***************************************************************************
