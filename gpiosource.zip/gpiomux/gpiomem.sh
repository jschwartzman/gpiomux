#!/bin/bash
chown root.gpio /dev/gpiomem && chmod g+rw /dev/gpiomem

